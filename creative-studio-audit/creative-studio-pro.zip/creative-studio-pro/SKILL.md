---
name: creative-studio-pro
description: Creative studio toolkit for premium websites and motion. Use whenever the user builds, designs, animates or reviews a website, landing page, UI, component, React or Next.js app, a 3D or Three.js / React Three Fiber scene, a GSAP animation (timeline, ScrollTrigger, SplitText, MorphSVG, useGSAP), view or page transitions, generative p5.js art, or a multi-file React artifact. Routes to 28 vetted modules from ui-ux-pro-max, Anthropic frontend-design, Vercel React skills, official GreenSock GSAP skills and threejs-skills. Not for Remotion video; use the Remotion skills for that.
license: Bundle of MIT and Apache-2.0 modules. See LICENSES/ and each module's LICENSE.txt.
---

# Creative Studio Pro (router)

This skill is a router. **Do not answer from this file alone.** Pick the module or modules that match the task, then read that module's `SKILL.md` in full before writing code. Read only what the task needs.

All module paths are relative to this skill's folder: `modules/<name>/SKILL.md`. When a module mentions its own files (such as `rules/...`, `references/...`, `scripts/...` or `templates/...`), resolve them inside that module's folder.

## Routing table

| Task | Read |
|---|---|
| Any website or UI. Read this first for look and feel. | `modules/frontend-design` |
| Pick a style, palette, font pairing or UX rules; generate a design system | `modules/ui-ux-pro-max` (see the script note below) |
| Review or audit UI and accessibility | `modules/web-design-guidelines` (fetches its rules from the web) |
| React or Next.js code quality and performance | `modules/vercel-react-best-practices` (`AGENTS.md` has every rule expanded) |
| Component API design and composition | `modules/vercel-composition-patterns` |
| Page or route transitions, shared-element animation in React | `modules/vercel-react-view-transitions` |
| Larger React + Tailwind + shadcn artifacts | `modules/web-artifacts-builder` |
| Generative or algorithmic art (p5.js) | `modules/algorithmic-art` |
| **GSAP:** basics, tweens, easing | `modules/gsap-core` |
| GSAP sequencing and choreography | `modules/gsap-timeline` |
| Scroll-driven animation, pinning, scrub | `modules/gsap-scrolltrigger` |
| GSAP in React or Next.js (`useGSAP`, cleanup) | `modules/gsap-react` |
| SplitText, MorphSVG, DrawSVG, MotionPath, CustomEase, Flip | `modules/gsap-plugins` |
| clamp, mapRange, snap, random helpers | `modules/gsap-utils` |
| Janky or slow animation | `modules/gsap-performance` |
| GSAP in Vue, Svelte or another framework | `modules/gsap-frameworks` |
| **Three.js:** scene, camera, renderer setup | `modules/threejs-fundamentals` |
| Geometry, materials (PBR), lighting and shadows, textures | `modules/threejs-geometry`, `-materials`, `-lighting`, `-textures` |
| Shaders and GLSL | `modules/threejs-shaders` |
| Bloom, DOF and other post effects | `modules/threejs-postprocessing` |
| GLTF and skeletal animation, morph targets | `modules/threejs-animation` |
| Raycasting, controls, mouse and touch | `modules/threejs-interaction` |
| Loading GLTF, HDR and other assets; compression and optimisation | `modules/threejs-loaders`, `modules/threejs-asset-pipeline` |
| Frame rate, draw calls, mobile performance | `modules/threejs-performance` |
| React Three Fiber and drei | `modules/threejs-react-three-fiber` |

Common combinations:
- **Premium landing page:** frontend-design + ui-ux-pro-max + gsap-scrolltrigger
- **3D hero website:** frontend-design + threejs-fundamentals + threejs-materials + threejs-lighting + threejs-postprocessing (add threejs-react-three-fiber in React)
- **Next.js app with motion:** vercel-react-best-practices + gsap-react or vercel-react-view-transitions

## ui-ux-pro-max script note

That module's `SKILL.md` shows commands such as `python "${CLAUDE_PLUGIN_ROOT}/.claude/skills/ui-ux-pro-max/scripts/search.py" ...`. In this bundle, use this skill's own folder instead:

```
python3 <this-skill-folder>/modules/ui-ux-pro-max/scripts/search.py "<query>" --design-system -p "Project"
```

The script is offline and only searches the CSV files in `modules/ui-ux-pro-max/data/`. It needs no API key. Its developer tests were removed from this bundle.

## Sources (unmodified module content)

- ui-ux-pro-max: nextlevelbuilder/ui-ux-pro-max-skill (MIT)
- frontend-design, web-artifacts-builder, algorithmic-art: anthropics/skills (Apache-2.0, LICENSE.txt in each module)
- vercel-*, web-design-guidelines: vercel-labs/agent-skills (MIT)
- gsap-*: greensock/gsap-skills (official, MIT)
- threejs-*: CloudAI-X/threejs-skills (MIT)
